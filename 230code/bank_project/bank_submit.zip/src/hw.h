#ifndef __HW6_H
#define __HW6_H

#include "bank.h"
#include "atm.h"
#include "command.h"
#include "trace.h"
#include "errors.h"

#endif
