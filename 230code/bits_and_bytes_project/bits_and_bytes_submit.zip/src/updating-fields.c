#include <stdio.h>
#include "bits_and_bytes.h"

int main() {
  updating_fields();
  return 0;
}
