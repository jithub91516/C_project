#include <stdio.h>
#include "bits_and_bytes.h"

int main() {
  print_bits();
  return 0;
}
