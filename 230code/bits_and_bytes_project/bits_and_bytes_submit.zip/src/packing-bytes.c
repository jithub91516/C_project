#include <stdio.h>
#include "bits_and_bytes.h"

int main() {
  packing_bytes();
  return 0;
}
